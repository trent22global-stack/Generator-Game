
import React from 'react'
type Props = React.HTMLAttributes<HTMLSpanElement> & { variant?: 'default'|'secondary'|'destructive' }
export function Badge({ className='', variant='default', ...rest }: Props) {
  const variants: Record<string,string> = {
    default:'bg-slate-900 text-white',
    secondary:'bg-slate-200 text-slate-900',
    destructive:'bg-red-100 text-red-700'
  }
  return <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${variants[variant]} ${className}`} {...rest} />
}
