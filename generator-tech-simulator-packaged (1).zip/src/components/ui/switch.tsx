
import React from 'react'
export function Switch({ checked, onCheckedChange }: { checked: boolean; onCheckedChange: (v:boolean)=>void }){
  return <button onClick={()=>onCheckedChange(!checked)} className={`w-12 h-6 rounded-full ${checked?'bg-green-500':'bg-slate-300'}`}><span className={`block h-5 w-5 bg-white rounded-full transition translate-y-0 ${checked?'translate-x-6':'translate-x-1'}`} /></button>
}
