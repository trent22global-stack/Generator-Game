
import React from 'react'
type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'default'|'secondary'|'outline'|'ghost'|'destructive' }
export function Button({ className='', variant='default', ...rest }: Props) {
  const variants: Record<string,string> = {
    default:'bg-blue-600 hover:bg-blue-700 text-white',
    secondary:'bg-slate-200 hover:bg-slate-300 text-slate-900',
    outline:'border border-slate-300 hover:bg-slate-50',
    ghost:'hover:bg-slate-100',
    destructive:'bg-red-600 hover:bg-red-700 text-white'
  }
  return <button className={`px-3 py-2 rounded-2xl text-sm font-medium transition ${variants[variant]} ${className}`} {...rest} />
}
