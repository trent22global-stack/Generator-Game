
import React from 'react'
export function TooltipProvider({ children }: any){ return children }
export function Tooltip({ children }: any){ return children }
export function TooltipTrigger({ asChild, children }: any){ return children }
export function TooltipContent({ children }: any){ return <span className="ml-2 text-xs text-slate-500">{children}</span> }
