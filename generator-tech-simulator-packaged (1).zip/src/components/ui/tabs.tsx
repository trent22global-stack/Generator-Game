
import React from 'react'
export function Tabs({ defaultValue, children }: any){ return <div data-default={defaultValue}>{children}</div> }
export function TabsList({ className='', ...rest }: React.HTMLAttributes<HTMLDivElement>){ return <div className={`inline-grid gap-2 ${className}`} {...rest} /> }
export function TabsTrigger({ value, children, onClick }: any){ return <button className="px-3 py-2 rounded-2xl bg-slate-200" onClick={onClick}>{children}</button> }
export function TabsContent({ children, className='' }: any){ return <div className={className}>{children}</div> }
