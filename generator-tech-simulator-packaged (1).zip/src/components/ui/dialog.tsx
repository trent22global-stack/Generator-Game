
import React from 'react'
export function Dialog({ open, onOpenChange, children }: any){ return open ? <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">{children}</div> : null }
export function DialogTrigger({ asChild, children }: any){ return children }
export function DialogContent({ className='', children }: any){ return <div className={`bg-white rounded-2xl border w-full max-w-xl ${className}`}>{children}</div> }
export function DialogHeader({ children }: any){ return <div className="p-4 border-b">{children}</div> }
export function DialogTitle({ children }: any){ return <h3 className="font-semibold">{children}</h3> }
