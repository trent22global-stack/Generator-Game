
import React from 'react'
export function Select({ value, onValueChange, children }: any){ return <div data-value={value}>{children}</div> }
export function SelectTrigger({ children }: any){ return <div className="border rounded-2xl px-3 py-2">{children}</div> }
export function SelectValue({ placeholder }: any){ return <span>{placeholder}</span> }
export function SelectContent({ children }: any){ return <div className="mt-2 p-2 border rounded-2xl bg-white shadow">{children}</div> }
export function SelectItem({ value, children, onSelect }: any){ return <div className="px-3 py-2 hover:bg-slate-100 rounded-xl cursor-pointer" onClick={()=>onSelect?onSelect(value):null}>{children}</div> }
