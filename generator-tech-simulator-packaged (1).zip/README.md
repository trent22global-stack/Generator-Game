
# Generator Technician Simulator

Production-ready build configs for **Netlify**, **Vercel**, and **GitHub Pages** are included.

## Run locally
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```
Output goes to `dist/`.

---

## Deploy: Netlify
- Uses `netlify.toml` (build: `npm run build`, publish: `dist`)
- SPA fallback is configured so client routes work.

## Deploy: Vercel
- `vercel.json` sets `buildCommand` and `outputDirectory` and includes a SPA rewrite.
- You can import the repo in Vercel and it will just work.

## Deploy: GitHub Pages
1. Make sure your default branch is `main` (or update the workflow trigger).
2. If deploying to `https://<user>.github.io/<repo>`, set your Vite base path:
   - Open `vite.config.ts` and set:
     ```ts
     import { defineConfig } from 'vite'
     import react from '@vitejs/plugin-react'
     export default defineConfig({
       plugins: [react()],
       base: '/<repo>/' // <-- replace with your repo name
     })
     ```
3. Push to GitHub; the included workflow `.github/workflows/deploy.yml` will build and publish to Pages.

---

## Notes
- If you don't need Tailwind, you can remove it from `package.json` and `index.css`.
- For custom domains on Netlify/Vercel, set the domain in their dashboards after the first deploy.
